from django.apps import AppConfig


class AppcompeticionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appCompeticion'
    verbose_name='App Competiciones'
    icon='fa fa-trophy'
